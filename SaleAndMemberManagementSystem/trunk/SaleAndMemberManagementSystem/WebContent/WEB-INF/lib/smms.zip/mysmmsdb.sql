-- MySQL dump 10.11
--
-- Host: localhost    Database: mysmmsdb
-- ------------------------------------------------------
-- Server version	5.0.51a-24+lenny4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `AUTHORITIES`
--

DROP TABLE IF EXISTS `AUTHORITIES`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `AUTHORITIES` (
  `AUTH_ID` bigint(20) NOT NULL,
  `AUTHORITY` varchar(50) NOT NULL,
  `USER_ID` char(20) default NULL,
  PRIMARY KEY  (`AUTH_ID`),
  KEY `FK_AUTHORITIES_USER_ID` (`USER_ID`),
  CONSTRAINT `FK_AUTHORITIES_USER_ID` FOREIGN KEY (`USER_ID`) REFERENCES `USERS` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `AUTHORITIES`
--

LOCK TABLES `AUTHORITIES` WRITE;
/*!40000 ALTER TABLE `AUTHORITIES` DISABLE KEYS */;
INSERT INTO `AUTHORITIES` VALUES (551,'ROLE_MEMBER','AA1000000001'),(601,'ROLE_MEMBER','AB1000000002'),(651,'ROLE_MEMBER','AB1000000003'),(701,'ROLE_MEMBER','AC1000000004'),(751,'ROLE_MEMBER','AC1000000006'),(801,'ROLE_MEMBER','AC1000000005'),(851,'ROLE_MEMBER','AC1000000007'),(901,'ROLE_MEMBER','AD1000000010'),(951,'ROLE_MEMBER','AD1000000011'),(1001,'ROLE_MEMBER','AD1000000008'),(1051,'ROLE_MEMBER','AD1000000012'),(1101,'ROLE_MEMBER','AD1000000014'),(1151,'ROLE_MEMBER','AD1000000009');
/*!40000 ALTER TABLE `AUTHORITIES` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BRANCE`
--

DROP TABLE IF EXISTS `BRANCE`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `BRANCE` (
  `BRANCE_CODE` int(11) NOT NULL auto_increment,
  `BRANCE_TEL` varchar(50) default NULL,
  `BRANCE_ADDRESS` text,
  `BRANCE_NAME` varchar(50) default NULL,
  `POST_CODE` varchar(50) default NULL,
  `BRANCE_PROVINCE` char(5) default NULL,
  PRIMARY KEY  (`BRANCE_CODE`),
  KEY `FK_BRANCE_BRANCE_PROVINCE` (`BRANCE_PROVINCE`),
  CONSTRAINT `FK_BRANCE_BRANCE_PROVINCE` FOREIGN KEY (`BRANCE_PROVINCE`) REFERENCES `PROVINCE` (`PROVINCE_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `BRANCE`
--

LOCK TABLES `BRANCE` WRITE;
/*!40000 ALTER TABLE `BRANCE` DISABLE KEYS */;
INSERT INTO `BRANCE` VALUES (1,'0899999999','ที่อยูสาขาจ้า','สำนักงานใหญ่สุดๆ','10250','10');
/*!40000 ALTER TABLE `BRANCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NODE1`
--

DROP TABLE IF EXISTS `NODE1`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `NODE1` (
  `NODE_ID` bigint(20) NOT NULL,
  `COMMISSIONS` int(11) default NULL,
  `INVITER` varchar(50) default NULL,
  `STATUS` char(1) default NULL,
  `SMILE_VALUE` int(11) default NULL,
  `DISPLAYNAME` varchar(50) default NULL,
  `USER_ID` char(20) default NULL,
  PRIMARY KEY  (`NODE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `NODE1`
--

LOCK TABLES `NODE1` WRITE;
/*!40000 ALTER TABLE `NODE1` DISABLE KEYS */;
INSERT INTO `NODE1` VALUES (1,220,'xxx','I',0,'xxx','AA1000000001'),(2,220,'xxx','I',0,'xx2','AB1000000002'),(3,0,'xxx','I',0,'xx3','AB1000000003'),(4,220,'xxx','I',0,'xx4','AC1000000004'),(5,0,'xxx','I',0,'zzz','AC1000000005'),(6,0,'xxx','I',0,'ccc','AC1000000006'),(7,0,'xxx','I',0,'vvv','AC1000000007'),(8,0,'xxx','I',0,'ggg','AD1000000008'),(9,0,'xx3','A',11000,'sss','AD1000000009'),(10,0,'xxx','I',0,'nnn','AD1000000010'),(11,0,'xxx','I',0,'mmm','AD1000000011'),(12,0,'xxx','I',0,'aaa','AD1000000012'),(14,0,'xxx','I',0,'www','AD1000000014');
/*!40000 ALTER TABLE `NODE1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `NODE_DEPT`
--

DROP TABLE IF EXISTS `NODE_DEPT`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `NODE_DEPT` (
  `LEVEL` varchar(20) NOT NULL,
  `UPPER` bigint(20) default NULL,
  `COUNT` int(11) default NULL,
  `MAX_NODE` int(11) default NULL,
  `NEXT_ID` bigint(20) default NULL,
  `VERSION` int(11) default NULL,
  PRIMARY KEY  (`LEVEL`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `NODE_DEPT`
--

LOCK TABLES `NODE_DEPT` WRITE;
/*!40000 ALTER TABLE `NODE_DEPT` DISABLE KEYS */;
INSERT INTO `NODE_DEPT` VALUES ('DETAIL',15,6,8,10,14);
/*!40000 ALTER TABLE `NODE_DEPT` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER1`
--

DROP TABLE IF EXISTS `ORDER1`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ORDER1` (
  `ORDER_ID` bigint(20) NOT NULL auto_increment,
  `TOTAL_QUANTITY` int(11) default NULL,
  `READED` tinyint(1) default '0',
  `BRANCE` int(11) default NULL,
  `TOTAL_SV` int(11) default NULL,
  `DATE` datetime default NULL,
  `SELLER_ID` char(20) default NULL,
  `TOTAL_PRICE` double default NULL,
  `USER_ID` char(20) default NULL,
  PRIMARY KEY  (`ORDER_ID`),
  KEY `FK_ORDER1_USER_ID` (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ORDER1`
--

LOCK TABLES `ORDER1` WRITE;
/*!40000 ALTER TABLE `ORDER1` DISABLE KEYS */;
INSERT INTO `ORDER1` VALUES (1,10,0,NULL,1000,'2010-12-10 18:01:18','AA1000000001',150,'AD1000000009'),(2,100,0,NULL,10000,'2010-12-10 18:04:42','AA1000000001',1500,'AD1000000009');
/*!40000 ALTER TABLE `ORDER1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ORDER1_PURCHESE`
--

DROP TABLE IF EXISTS `ORDER1_PURCHESE`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ORDER1_PURCHESE` (
  `Order_ORDER_ID` bigint(20) NOT NULL,
  `purchese_P_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`Order_ORDER_ID`,`purchese_P_ID`),
  KEY `FK_ORDER1_PURCHESE_purchese_P_ID` (`purchese_P_ID`),
  CONSTRAINT `FK_ORDER1_PURCHESE_Order_ORDER_ID` FOREIGN KEY (`Order_ORDER_ID`) REFERENCES `ORDER1` (`ORDER_ID`),
  CONSTRAINT `FK_ORDER1_PURCHESE_purchese_P_ID` FOREIGN KEY (`purchese_P_ID`) REFERENCES `PURCHESE` (`P_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ORDER1_PURCHESE`
--

LOCK TABLES `ORDER1_PURCHESE` WRITE;
/*!40000 ALTER TABLE `ORDER1_PURCHESE` DISABLE KEYS */;
/*!40000 ALTER TABLE `ORDER1_PURCHESE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PROVINCE`
--

DROP TABLE IF EXISTS `PROVINCE`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `PROVINCE` (
  `PROVINCE_CODE` char(5) NOT NULL default '',
  `PROVINCE` varchar(100) default NULL,
  PRIMARY KEY  (`PROVINCE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `PROVINCE`
--

LOCK TABLES `PROVINCE` WRITE;
/*!40000 ALTER TABLE `PROVINCE` DISABLE KEYS */;
INSERT INTO `PROVINCE` VALUES ('10','กรุงเทพมหานคร'),('11','สมุทรปราการ'),('12','นนทบุรี'),('13','ปทุมธานี'),('14','พระนครศรีอยุธยา'),('15','อ่างทอง'),('16','ลพบุรี'),('17','สิงห์บุรี'),('18','ชัยนาท'),('19','สระบุรี'),('20','ชลบุรี'),('21','ระยอง'),('22','จันทบุรี'),('23','ตราด'),('24','ฉะเชิงเทรา'),('25','ปราจีนบุรี'),('26','นครนายก'),('27','สระแก้ว'),('30','นครราชสีมา'),('31','บุรีรัมย์'),('32','สุรินทร์'),('33','ศรีสะเกษ'),('34','อุบลราชธานี'),('35','ยโสธร'),('36','ชัยภูมิ'),('37','อำนาจเจริญ'),('39','หนองบัวลำภู'),('40','ขอนแก่น'),('41','อุดรธานี'),('42','เลย'),('43','หนองคาย'),('44','มหาสารคาม'),('45','ร้อยเอ็ด'),('46','กาฬสินธุ์'),('47','สกลนคร'),('48','นครพนม'),('49','มุกดาหาร'),('50','เชียงใหม่'),('51','ลำพูน'),('52','ลำปาง'),('53','อุตรดิตถ์'),('54','แพร่'),('55','น่าน'),('56','พะเยา'),('57','เชียงราย'),('58','แม่ฮ่องสอน'),('60','นครสวรรค์'),('61','อุทัยธานี'),('62','กำแพงเพชร'),('63','ตาก'),('64','สุโขทัย'),('65','พิษณุโลก'),('66','พิจิตร'),('67','เพชรบูรณ์'),('70','ราชบุรี'),('71','กาญจนบุรี'),('72','สุพรรณบุรี'),('73','นครปฐม'),('74','สมุทรสาคร'),('75','สมุทรสงคราม'),('76','เพชรบุรี'),('77','ประจวบคีรีขันธ์'),('80','นครศรีธรรมราช'),('81','กระบี่'),('82','พังงา'),('83','ภูเก็ต'),('84','สุราษฎร์ธานี'),('85','ระนอง'),('86','ชุมพร'),('90','สงขลา'),('91','สตูล'),('92','ตรัง'),('93','พัทลุง'),('94','ปัตตานี'),('95','ยะลา'),('96','นราธิวาส');
/*!40000 ALTER TABLE `PROVINCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `PURCHESE`
--

DROP TABLE IF EXISTS `PURCHESE`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `PURCHESE` (
  `P_ID` bigint(20) NOT NULL auto_increment,
  `PSV` int(11) default NULL,
  `QUANTITY` int(11) default NULL,
  `P_PRICE` double default NULL,
  `S_ID` bigint(20) default NULL,
  `ORDER_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`P_ID`),
  KEY `FK_PURCHESE_S_ID` (`S_ID`),
  KEY `FK_PURCHESE_ORDER_ID` (`ORDER_ID`),
  CONSTRAINT `FK_PURCHESE_ORDER_ID` FOREIGN KEY (`ORDER_ID`) REFERENCES `ORDER1` (`ORDER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `PURCHESE`
--

LOCK TABLES `PURCHESE` WRITE;
/*!40000 ALTER TABLE `PURCHESE` DISABLE KEYS */;
INSERT INTO `PURCHESE` VALUES (1,1000,10,150,1,1),(2,10000,100,1500,1,2);
/*!40000 ALTER TABLE `PURCHESE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SEQUENCE`
--

DROP TABLE IF EXISTS `SEQUENCE`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `SEQUENCE` (
  `SEQ_NAME` varchar(50) NOT NULL,
  `SEQ_COUNT` decimal(38,0) default NULL,
  PRIMARY KEY  (`SEQ_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `SEQUENCE`
--

LOCK TABLES `SEQUENCE` WRITE;
/*!40000 ALTER TABLE `SEQUENCE` DISABLE KEYS */;
INSERT INTO `SEQUENCE` VALUES ('SEQ_GEN','1200');
/*!40000 ALTER TABLE `SEQUENCE` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SKU`
--

DROP TABLE IF EXISTS `SKU`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `SKU` (
  `S_ID` bigint(20) NOT NULL auto_increment,
  `PRICE` double default NULL,
  `DESCRIPTION` text,
  `NAME` varchar(50) NOT NULL,
  `SV` int(11) default NULL,
  `IMAGE` varchar(255) default NULL,
  `MEMBER_PRICE` double default NULL,
  `PRICE_DISCOUNT` double default NULL,
  `DISCOUNT` int(11) default NULL,
  PRIMARY KEY  (`S_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `SKU`
--

LOCK TABLES `SKU` WRITE;
/*!40000 ALTER TABLE `SKU` DISABLE KEYS */;
INSERT INTO `SKU` VALUES (1,15,'xxx','xxx',100,NULL,12,0,2);
/*!40000 ALTER TABLE `SKU` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USERS`
--

DROP TABLE IF EXISTS `USERS`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `USERS` (
  `USER_ID` char(20) NOT NULL default '',
  `TEL` varchar(30) default NULL,
  `ENABLED` tinyint(4) default NULL,
  `BRANCE` varchar(50) default NULL,
  `ADDRESS2` text,
  `PASSWORD` varchar(255) default NULL,
  `BONUS_TEAM` int(11) default NULL,
  `TEL2` varchar(30) default NULL,
  `BRANCE_CARD` varchar(50) default NULL,
  `EMAIL` varchar(100) default NULL,
  `ADDRESS` text,
  `SURNAME` varchar(50) default NULL,
  `REV_CARD` tinyint(1) default '0',
  `NAME` varchar(50) default NULL,
  `BONUS_INV` int(11) default NULL,
  `BANK` varchar(50) default NULL,
  `BANK_BRANCE` varchar(50) default NULL,
  `CODE_IDENT` varchar(30) default NULL,
  `BONUS_LAST` int(11) default NULL,
  `TYPE_ACCOUNT` varchar(50) default NULL,
  `BANK_ACCOUNT` varchar(50) default NULL,
  `NODE_ID` bigint(20) default NULL,
  `PROVINCE` char(5) default NULL,
  PRIMARY KEY  (`USER_ID`),
  KEY `FK_USERS_PROVINCE` (`PROVINCE`),
  KEY `FK_USERS_NODE_ID` (`NODE_ID`),
  CONSTRAINT `FK_USERS_NODE_ID` FOREIGN KEY (`NODE_ID`) REFERENCES `NODE1` (`NODE_ID`),
  CONSTRAINT `FK_USERS_PROVINCE` FOREIGN KEY (`PROVINCE`) REFERENCES `PROVINCE` (`PROVINCE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `USERS`
--

LOCK TABLES `USERS` WRITE;
/*!40000 ALTER TABLE `USERS` DISABLE KEYS */;
INSERT INTO `USERS` VALUES ('AA1000000001','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','xxxxxxxxxxxxxx','xxx',0,'xxx',0,'ธนาคารไทยพานิชย์','xxx','3451000629521',1107,'xxx','1234567890',1,'10'),('AB1000000002','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','xxxxxxxx','xx2',0,'xx2',0,'ธนาคารไทยพานิชย์','xxx','3451000629521',1107,'xxx','1234567890',2,'10'),('AB1000000003','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','xxxxxxxxxxxxxxxxxxxx','xx3',0,'xx3',242,'ธนาคารไทยพานิชย์','xxx','3451000629521',242,'xxx','1234567890',3,'10'),('AC1000000004','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','xxxxxxxxxxxxxx','xx4',0,'xx4',0,'ธนาคารไทยพานิชย์','xxx','3451000629521',1107,'xxx','1234567890',4,'10'),('AC1000000005','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','zzzzzzzzzzzzzzzz','zzz',0,'zzz',0,'ธนาคารไทยพานิชย์','xxx','3451000629521',1107,'xxx','1234567890',5,'10'),('AC1000000006','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','ccccccccc','ccc',0,'ccc',0,'ธนาคารไทยพานิชย์','xxx','3451000629521',1107,'xxx','1234567890',6,'10'),('AC1000000007','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','vvvvvvvvvvvvv','vvv',0,'vvv',0,'ธนาคารไทยพานิชย์','vvv','3451000629521',1107,'vvv','1234567890',7,'10'),('AD1000000008','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','xxxxxxxxxxxx','ggg',0,'ggg',0,'ธนาคารไทยพานิชย์','gggg','3451000629521',1107,'gggg','1234567890',8,'10'),('AD1000000009','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',242,'','สำนักงานใหญ่สุดๆ','','ssssssssssssss','sss',0,'sss',0,'ธนาคารไทยพานิชย์','sss','3451000629521',242,'sss','1234567890',9,'10'),('AD1000000010','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','nnnnnnnnnnn','nnn',0,'nnn',0,'ธนาคารไทยพานิชย์','nnn','3451000629521',1107,'nnn','1234567890',10,'10'),('AD1000000011','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','mmmmmmmmm','mmm',0,'mmm',0,'ธนาคารไทยพานิชย์','mmmm','3451000629521',1107,'mmm','1234567890',11,'10'),('AD1000000012','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','aaaaaaaaaaaaaaaa','aaa',0,'aaa',0,'ธนาคารไทยพานิชย์','aaaa','3451000629521',1107,'aaaa','1234567890',12,'10'),('AD1000000014','123456789',1,'สำนักงานใหญ่สุดๆ','','b60d121b438a380c343d5ec3c2037564b82ffef3',0,'','สำนักงานใหญ่สุดๆ','','wwwwwww','www',0,'www',0,'ธนาคารไทยพานิชย์','www','3451000629521',1107,'www','1234567890',14,'10');
/*!40000 ALTER TABLE `USERS` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `USERS_AUTHORITIES`
--

DROP TABLE IF EXISTS `USERS_AUTHORITIES`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `USERS_AUTHORITIES` (
  `Users_USER_ID` char(20) NOT NULL default '',
  `authorities_AUTH_ID` bigint(20) NOT NULL,
  PRIMARY KEY  (`Users_USER_ID`,`authorities_AUTH_ID`),
  KEY `FK_USERS_AUTHORITIES_authorities_AUTH_ID` (`authorities_AUTH_ID`),
  CONSTRAINT `FK_USERS_AUTHORITIES_Users_USER_ID` FOREIGN KEY (`Users_USER_ID`) REFERENCES `USERS` (`USER_ID`),
  CONSTRAINT `FK_USERS_AUTHORITIES_authorities_AUTH_ID` FOREIGN KEY (`authorities_AUTH_ID`) REFERENCES `AUTHORITIES` (`AUTH_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `USERS_AUTHORITIES`
--

LOCK TABLES `USERS_AUTHORITIES` WRITE;
/*!40000 ALTER TABLE `USERS_AUTHORITIES` DISABLE KEYS */;
INSERT INTO `USERS_AUTHORITIES` VALUES ('AA1000000001',551),('AB1000000002',601),('AB1000000003',651),('AC1000000004',701),('AC1000000006',751),('AC1000000005',801),('AC1000000007',851),('AD1000000010',901),('AD1000000011',951),('AD1000000008',1001),('AD1000000012',1051),('AD1000000014',1101),('AD1000000009',1151);
/*!40000 ALTER TABLE `USERS_AUTHORITIES` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2010-11-30 15:38:23
